w=0;
x= exp(j*w)
stem(x)